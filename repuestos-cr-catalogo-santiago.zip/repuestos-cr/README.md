Esta es mi parte-Adrián Emilio Anchia Villarreal

---

## Módulo agregado: Catálogo del Cliente (Santiago) — HU-11 a HU-14

Usa las entidades de catálogo (`Repuesto`, `Marca`, del módulo de Eduardo) y el
`Inventario` (módulo de Adrián) **sin crear ninguna tabla propia**. Solo agrega:

- `service/CatalogoService.java` y `service/RepuestoCatalogoDTO.java`: combinan en
  memoria el `Repuesto` con el stock del `Inventario` para calcular disponibilidad.
- `controllers/CatalogoController.java`: expone las 3 pantallas.
- `templates/index.html` (Pantalla 2 – Inicio), `templates/catalogo/listado.html`
  (Pantalla 3 – Catálogo) y `templates/catalogo/detalle.html` (Pantalla 4 – Detalle).

| HU | Descripción | Dónde |
|----|-------------|-------|
| HU-11 | Buscar repuestos por nombre | `GET /catalogo?q=...` |
| HU-12 | Filtrar por marca | `GET /catalogo?marca=...` |
| HU-13 | Ver disponibilidad (stock del Inventario) | `GET /catalogo?disponibles=true`, badge Disponible/Agotado |
| HU-14 | Ver detalle de un repuesto | `GET /catalogo/{id}` |

Los campos `descripcion`, `precio` y `marca` se agregaron de forma **temporal**
a la clase `Repuesto` (igual que hizo Adrián con la tabla `repuesto`), y se creó
una clase `Marca` temporal, solo para poder probar este módulo mientras Eduardo
entrega el módulo real de Catálogo. Al integrar el proyecto completo hay que
reemplazar ambas clases por las reales del módulo de Eduardo.
