package com.autopartescr.repuestos.repository;

import com.autopartescr.repuestos.domain.Marca;
import org.springframework.data.jpa.repository.JpaRepository;

// TEMPORAL - borrar al integrar con el modulo de Eduardo (Marca real).
// Santiago solo lee esta tabla (HU-12), no es su dueno.
public interface MarcaRepository extends JpaRepository<Marca, Integer> {
}
