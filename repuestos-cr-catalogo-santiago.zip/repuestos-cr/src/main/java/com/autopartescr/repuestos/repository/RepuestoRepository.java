package com.autopartescr.repuestos.repository;

import com.autopartescr.repuestos.domain.Repuesto;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

// TEMPORAL - borrar al integrar con el modulo de Eduardo (Repuesto real)
public interface RepuestoRepository extends JpaRepository<Repuesto, Integer> {

    // HU-11: buscar repuestos por nombre (coincidencia parcial, sin distinguir mayus/minus)
    List<Repuesto> findByNombreContainingIgnoreCase(String nombre);

    // HU-12: filtrar el catalogo por marca
    List<Repuesto> findByMarca_IdMarca(Integer idMarca);

    // HU-11 + HU-12 combinados: buscar por nombre dentro de una marca especifica
    List<Repuesto> findByNombreContainingIgnoreCaseAndMarca_IdMarca(String nombre, Integer idMarca);
}
