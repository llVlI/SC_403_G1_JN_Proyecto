package com.autopartescr.repuestos.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;

/**
 * TEMPORAL.
 * Esta clase existe solo para que los modulos de Inventario (Adrian) y
 * Catalogo del Cliente (Santiago) compilen y se puedan probar de forma
 * independiente mientras Eduardo desarrolla el modulo real de Catalogo
 * (Repuesto, Marca, Categoria).
 *
 * Se agregaron descripcion, precio y marca porque las HU-11 a HU-14
 * (buscar, filtrar por marca, ver disponibilidad y ver detalle) los
 * necesitan para mostrar la pantalla de Catalogo y de Detalle.
 *
 * Cuando se integren los modulos:
 * 1. Borrar este archivo.
 * 2. Usar la clase Repuesto real del paquete de Eduardo.
 * 3. Mientras la tabla se llame "repuesto" y tenga estas mismas columnas
 *    (id, nombre, descripcion, precio, marca_id), Hibernate no tendra
 *    problema en mapear las relaciones de Inventario y de Catalogo hacia
 *    el Repuesto real.
 */
@Data
@Entity
@Table(name = "repuesto")
public class Repuesto implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer idRepuesto;

    @Column(name = "nombre", nullable = false, length = 100)
    @NotNull
    @Size(max = 100)
    private String nombre;

    @Column(name = "descripcion", length = 500)
    @Size(max = 500)
    private String descripcion;

    @Column(name = "precio", precision = 10, scale = 2)
    private BigDecimal precio;

    // HU-12: filtrar el catalogo por marca.
    @ManyToOne
    @JoinColumn(name = "marca_id")
    private Marca marca;
}
