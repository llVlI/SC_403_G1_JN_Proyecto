package com.autopartescr.repuestos.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import lombok.Data;

/**
 * TEMPORAL.
 * Igual que Repuesto, esta clase existe solo para que el modulo de
 * Catalogo del Cliente (Santiago) compile y se pueda probar de forma
 * independiente mientras Eduardo desarrolla el modulo real de Catalogo
 * (Repuesto, Marca, Categoria).
 *
 * Santiago NO es dueno de esta tabla: solo la consume (HU-12, filtrar
 * por marca). Al integrar el proyecto completo, se debe usar la clase
 * Marca real del paquete de Eduardo y eliminar este archivo.
 */
@Data
@Entity
@Table(name = "marca")
public class Marca implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer idMarca;

    @Column(name = "nombre", nullable = false, length = 60, unique = true)
    @NotNull
    @Size(max = 60)
    private String nombre;
}
