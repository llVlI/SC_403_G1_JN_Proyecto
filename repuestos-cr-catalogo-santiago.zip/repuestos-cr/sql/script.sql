-- =====================================================
-- AutoPartes CR - Script SQL del modulo de Adrian
-- (Usuarios, Roles, Clientes, Inventario)
-- =====================================================

CREATE DATABASE IF NOT EXISTS autopartes_cr;
USE autopartes_cr;

CREATE USER IF NOT EXISTS 'autopartes_user'@'localhost' IDENTIFIED BY 'autopartes123';
GRANT ALL PRIVILEGES ON autopartes_cr.* TO 'autopartes_user'@'localhost';
FLUSH PRIVILEGES;

-- Tabla de roles
CREATE TABLE IF NOT EXISTS rol (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(40) NOT NULL UNIQUE
);

INSERT INTO rol (nombre) VALUES
    ('ADMINISTRADOR'),
    ('CLIENTE'),
    ('ENCARGADO_VENTAS');

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    rol_id INT NOT NULL,
    FOREIGN KEY (rol_id) REFERENCES rol(id)
);

-- Usuario administrador de prueba (correo: admin@autopartescr.com / clave: admin123)
INSERT INTO usuario (nombre, email, password, rol_id)
VALUES ('Administrador', 'admin@autopartescr.com', 'admin123',
        (SELECT id FROM rol WHERE nombre = 'ADMINISTRADOR'));

-- Tabla de clientes (datos adicionales de un usuario con rol CLIENTE)
CREATE TABLE IF NOT EXISTS cliente (
    id INT AUTO_INCREMENT PRIMARY KEY,
    telefono VARCHAR(20),
    direccion VARCHAR(200),
    usuario_id INT NOT NULL UNIQUE,
    FOREIGN KEY (usuario_id) REFERENCES usuario(id)
);

-- =====================================================
-- NOTA IMPORTANTE PARA LA INTEGRACION:
-- Las tablas "marca" y "repuesto" pertenecen al modulo
-- de Eduardo (Catalogo de Repuestos). Aqui se crea una
-- version minima SOLO para poder probar los modulos de
-- Inventario (Adrian) y Catalogo del Cliente (Santiago)
-- de forma independiente. Al integrar el proyecto
-- completo, se deben usar las tablas reales del modulo
-- de Eduardo (con mas columnas si aplica, ej. categoria,
-- imagen, etc.) y eliminar estos CREATE TABLE duplicados.
-- =====================================================
CREATE TABLE IF NOT EXISTS marca (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(60) NOT NULL UNIQUE
);

INSERT INTO marca (nombre) VALUES
    ('Bosch'),
    ('Toyota'),
    ('ACDelco');

CREATE TABLE IF NOT EXISTS repuesto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion VARCHAR(500),
    precio DECIMAL(10,2),
    marca_id INT,
    FOREIGN KEY (marca_id) REFERENCES marca(id)
);

INSERT INTO repuesto (nombre, descripcion, precio, marca_id) VALUES
    ('Pastilla de freno delantera', 'Juego de pastillas de freno delanteras, alto rendimiento.', 18500.00,
        (SELECT id FROM marca WHERE nombre = 'Bosch')),
    ('Filtro de aceite', 'Filtro de aceite compatible con motores 1.6L a 2.0L.', 4500.00,
        (SELECT id FROM marca WHERE nombre = 'Toyota')),
    ('Bateria 12V 45Ah', 'Bateria libre de mantenimiento, 45Ah, 12 meses de garantia.', 65000.00,
        (SELECT id FROM marca WHERE nombre = 'ACDelco')),
    ('Filtro de aire', 'Filtro de aire de alto flujo para mejor rendimiento del motor.', 7200.00,
        (SELECT id FROM marca WHERE nombre = 'Bosch')),
    ('Amortiguador trasero', 'Amortiguador trasero de gas, para uso urbano y carretera.', 32000.00,
        (SELECT id FROM marca WHERE nombre = 'Toyota'));

-- Tabla de inventario (HU-07 actualizar stock, HU-08 reporte, HU-13 disponibilidad en el catalogo)
CREATE TABLE IF NOT EXISTS inventario (
    id INT AUTO_INCREMENT PRIMARY KEY,
    repuesto_id INT NOT NULL UNIQUE,
    cantidad_actual INT NOT NULL DEFAULT 0,
    cantidad_minima INT NOT NULL DEFAULT 0,
    FOREIGN KEY (repuesto_id) REFERENCES repuesto(id)
);

INSERT INTO inventario (repuesto_id, cantidad_actual, cantidad_minima)
VALUES
    (1, 3, 10),   -- stock bajo a proposito, para ver la alerta
    (2, 25, 5),
    (3, 8, 4),
    (4, 0, 5),    -- sin stock a proposito, para ver "Agotado" en el catalogo (HU-13)
    (5, 12, 3);
